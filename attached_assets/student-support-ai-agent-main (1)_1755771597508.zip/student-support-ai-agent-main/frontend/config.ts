// Configuration file for Concern2Care
// All configuration values for the application

// Demo mode configuration
export const isDemoMode = true;

// Application settings
export const appName = "Concern2Care";
export const appDescription = "AI-Powered Student Support System";
