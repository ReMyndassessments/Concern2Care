import { Service } from "encore.dev/service";

export default new Service("health");
